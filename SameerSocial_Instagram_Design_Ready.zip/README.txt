Sameer Social Android Project — Version 2.0

This is an Android WebView wrapper around the existing Sameer Social V2 web prototype.
Open this folder in Android Studio and build the APK:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The prototype includes the previously prepared local UI/features. It is not yet a production
online social network; Supabase authentication/database integration is still a separate step.
